/*
 * system.h - SOPC Builder system and BSP software package information
 *
 * Machine generated for CPU 'cpu' in SOPC Builder design 'cpu'
 * SOPC Builder design path: E:/DE1-SOC/class10-Digital_Freq/cpu.sopcinfo
 *
 * Generated: Thu Jun 29 19:04:10 CST 2017
 */

/*
 * DO NOT MODIFY THIS FILE
 *
 * Changing this file will have subtle consequences
 * which will almost certainly lead to a nonfunctioning
 * system. If you do modify this file, be aware that your
 * changes will be overwritten and lost when this file
 * is generated again.
 *
 * DO NOT MODIFY THIS FILE
 */

/*
 * License Agreement
 *
 * Copyright (c) 2008
 * Altera Corporation, San Jose, California, USA.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * This agreement shall be governed in all respects by the laws of the State
 * of California and by the laws of the United States of America.
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/* Include definitions from linker script generator */
#include "linker.h"


/*
 * CPU configuration
 *
 */

#define ALT_CPU_ARCHITECTURE "altera_nios2_qsys"
#define ALT_CPU_BIG_ENDIAN 0
#define ALT_CPU_BREAK_ADDR 0x08000820
#define ALT_CPU_CPU_FREQ 100000000u
#define ALT_CPU_CPU_ID_SIZE 1
#define ALT_CPU_CPU_ID_VALUE 0x00000000
#define ALT_CPU_CPU_IMPLEMENTATION "fast"
#define ALT_CPU_DATA_ADDR_WIDTH 0x1c
#define ALT_CPU_DCACHE_LINE_SIZE 32
#define ALT_CPU_DCACHE_LINE_SIZE_LOG2 5
#define ALT_CPU_DCACHE_SIZE 2048
#define ALT_CPU_EXCEPTION_ADDR 0x04000020
#define ALT_CPU_FLUSHDA_SUPPORTED
#define ALT_CPU_FREQ 100000000
#define ALT_CPU_HARDWARE_DIVIDE_PRESENT 0
#define ALT_CPU_HARDWARE_MULTIPLY_PRESENT 1
#define ALT_CPU_HARDWARE_MULX_PRESENT 0
#define ALT_CPU_HAS_DEBUG_CORE 1
#define ALT_CPU_HAS_DEBUG_STUB
#define ALT_CPU_HAS_JMPI_INSTRUCTION
#define ALT_CPU_ICACHE_LINE_SIZE 32
#define ALT_CPU_ICACHE_LINE_SIZE_LOG2 5
#define ALT_CPU_ICACHE_SIZE 4096
#define ALT_CPU_INITDA_SUPPORTED
#define ALT_CPU_INST_ADDR_WIDTH 0x1c
#define ALT_CPU_NAME "cpu"
#define ALT_CPU_NUM_OF_SHADOW_REG_SETS 0
#define ALT_CPU_RESET_ADDR 0x04000000


/*
 * CPU configuration (with legacy prefix - don't use these anymore)
 *
 */

#define NIOS2_BIG_ENDIAN 0
#define NIOS2_BREAK_ADDR 0x08000820
#define NIOS2_CPU_FREQ 100000000u
#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0x00000000
#define NIOS2_CPU_IMPLEMENTATION "fast"
#define NIOS2_DATA_ADDR_WIDTH 0x1c
#define NIOS2_DCACHE_LINE_SIZE 32
#define NIOS2_DCACHE_LINE_SIZE_LOG2 5
#define NIOS2_DCACHE_SIZE 2048
#define NIOS2_EXCEPTION_ADDR 0x04000020
#define NIOS2_FLUSHDA_SUPPORTED
#define NIOS2_HARDWARE_DIVIDE_PRESENT 0
#define NIOS2_HARDWARE_MULTIPLY_PRESENT 1
#define NIOS2_HARDWARE_MULX_PRESENT 0
#define NIOS2_HAS_DEBUG_CORE 1
#define NIOS2_HAS_DEBUG_STUB
#define NIOS2_HAS_JMPI_INSTRUCTION
#define NIOS2_ICACHE_LINE_SIZE 32
#define NIOS2_ICACHE_LINE_SIZE_LOG2 5
#define NIOS2_ICACHE_SIZE 4096
#define NIOS2_INITDA_SUPPORTED
#define NIOS2_INST_ADDR_WIDTH 0x1c
#define NIOS2_NUM_OF_SHADOW_REG_SETS 0
#define NIOS2_RESET_ADDR 0x04000000


/*
 * Define for each module class mastered by the CPU
 *
 */

#define __ALTERA_AVALON_JTAG_UART
#define __ALTERA_AVALON_NEW_SDRAM_CONTROLLER
#define __ALTERA_AVALON_PIO
#define __ALTERA_AVALON_SYSID_QSYS
#define __ALTERA_AVALON_TIMER
#define __ALTERA_AVALON_UART
#define __ALTERA_NIOS2_QSYS


/*
 * Duty_cycle_a configuration
 *
 */

#define ALT_MODULE_CLASS_Duty_cycle_a altera_avalon_pio
#define DUTY_CYCLE_A_BASE 0x8001090
#define DUTY_CYCLE_A_BIT_CLEARING_EDGE_REGISTER 0
#define DUTY_CYCLE_A_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DUTY_CYCLE_A_CAPTURE 0
#define DUTY_CYCLE_A_DATA_WIDTH 32
#define DUTY_CYCLE_A_DO_TEST_BENCH_WIRING 0
#define DUTY_CYCLE_A_DRIVEN_SIM_VALUE 0
#define DUTY_CYCLE_A_EDGE_TYPE "NONE"
#define DUTY_CYCLE_A_FREQ 100000000
#define DUTY_CYCLE_A_HAS_IN 1
#define DUTY_CYCLE_A_HAS_OUT 0
#define DUTY_CYCLE_A_HAS_TRI 0
#define DUTY_CYCLE_A_IRQ -1
#define DUTY_CYCLE_A_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DUTY_CYCLE_A_IRQ_TYPE "NONE"
#define DUTY_CYCLE_A_NAME "/dev/Duty_cycle_a"
#define DUTY_CYCLE_A_RESET_VALUE 0
#define DUTY_CYCLE_A_SPAN 16
#define DUTY_CYCLE_A_TYPE "altera_avalon_pio"


/*
 * Duty_cycle_b configuration
 *
 */

#define ALT_MODULE_CLASS_Duty_cycle_b altera_avalon_pio
#define DUTY_CYCLE_B_BASE 0x8001080
#define DUTY_CYCLE_B_BIT_CLEARING_EDGE_REGISTER 0
#define DUTY_CYCLE_B_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DUTY_CYCLE_B_CAPTURE 0
#define DUTY_CYCLE_B_DATA_WIDTH 32
#define DUTY_CYCLE_B_DO_TEST_BENCH_WIRING 0
#define DUTY_CYCLE_B_DRIVEN_SIM_VALUE 0
#define DUTY_CYCLE_B_EDGE_TYPE "NONE"
#define DUTY_CYCLE_B_FREQ 100000000
#define DUTY_CYCLE_B_HAS_IN 1
#define DUTY_CYCLE_B_HAS_OUT 0
#define DUTY_CYCLE_B_HAS_TRI 0
#define DUTY_CYCLE_B_IRQ -1
#define DUTY_CYCLE_B_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DUTY_CYCLE_B_IRQ_TYPE "NONE"
#define DUTY_CYCLE_B_NAME "/dev/Duty_cycle_b"
#define DUTY_CYCLE_B_RESET_VALUE 0
#define DUTY_CYCLE_B_SPAN 16
#define DUTY_CYCLE_B_TYPE "altera_avalon_pio"


/*
 * Freq_a configuration
 *
 */

#define ALT_MODULE_CLASS_Freq_a altera_avalon_pio
#define FREQ_A_BASE 0x80010d0
#define FREQ_A_BIT_CLEARING_EDGE_REGISTER 0
#define FREQ_A_BIT_MODIFYING_OUTPUT_REGISTER 0
#define FREQ_A_CAPTURE 0
#define FREQ_A_DATA_WIDTH 32
#define FREQ_A_DO_TEST_BENCH_WIRING 0
#define FREQ_A_DRIVEN_SIM_VALUE 0
#define FREQ_A_EDGE_TYPE "NONE"
#define FREQ_A_FREQ 100000000
#define FREQ_A_HAS_IN 1
#define FREQ_A_HAS_OUT 0
#define FREQ_A_HAS_TRI 0
#define FREQ_A_IRQ -1
#define FREQ_A_IRQ_INTERRUPT_CONTROLLER_ID -1
#define FREQ_A_IRQ_TYPE "NONE"
#define FREQ_A_NAME "/dev/Freq_a"
#define FREQ_A_RESET_VALUE 0
#define FREQ_A_SPAN 16
#define FREQ_A_TYPE "altera_avalon_pio"


/*
 * Freq_b configuration
 *
 */

#define ALT_MODULE_CLASS_Freq_b altera_avalon_pio
#define FREQ_B_BASE 0x80010c0
#define FREQ_B_BIT_CLEARING_EDGE_REGISTER 0
#define FREQ_B_BIT_MODIFYING_OUTPUT_REGISTER 0
#define FREQ_B_CAPTURE 0
#define FREQ_B_DATA_WIDTH 32
#define FREQ_B_DO_TEST_BENCH_WIRING 0
#define FREQ_B_DRIVEN_SIM_VALUE 0
#define FREQ_B_EDGE_TYPE "NONE"
#define FREQ_B_FREQ 100000000
#define FREQ_B_HAS_IN 1
#define FREQ_B_HAS_OUT 0
#define FREQ_B_HAS_TRI 0
#define FREQ_B_IRQ -1
#define FREQ_B_IRQ_INTERRUPT_CONTROLLER_ID -1
#define FREQ_B_IRQ_TYPE "NONE"
#define FREQ_B_NAME "/dev/Freq_b"
#define FREQ_B_RESET_VALUE 0
#define FREQ_B_SPAN 16
#define FREQ_B_TYPE "altera_avalon_pio"


/*
 * Freq_standard configuration
 *
 */

#define ALT_MODULE_CLASS_Freq_standard altera_avalon_pio
#define FREQ_STANDARD_BASE 0x80010b0
#define FREQ_STANDARD_BIT_CLEARING_EDGE_REGISTER 0
#define FREQ_STANDARD_BIT_MODIFYING_OUTPUT_REGISTER 0
#define FREQ_STANDARD_CAPTURE 0
#define FREQ_STANDARD_DATA_WIDTH 32
#define FREQ_STANDARD_DO_TEST_BENCH_WIRING 0
#define FREQ_STANDARD_DRIVEN_SIM_VALUE 0
#define FREQ_STANDARD_EDGE_TYPE "NONE"
#define FREQ_STANDARD_FREQ 100000000
#define FREQ_STANDARD_HAS_IN 1
#define FREQ_STANDARD_HAS_OUT 0
#define FREQ_STANDARD_HAS_TRI 0
#define FREQ_STANDARD_IRQ -1
#define FREQ_STANDARD_IRQ_INTERRUPT_CONTROLLER_ID -1
#define FREQ_STANDARD_IRQ_TYPE "NONE"
#define FREQ_STANDARD_NAME "/dev/Freq_standard"
#define FREQ_STANDARD_RESET_VALUE 0
#define FREQ_STANDARD_SPAN 16
#define FREQ_STANDARD_TYPE "altera_avalon_pio"


/*
 * System configuration
 *
 */

#define ALT_DEVICE_FAMILY "Cyclone V"
#define ALT_ENHANCED_INTERRUPT_API_PRESENT
#define ALT_IRQ_BASE NULL
#define ALT_LOG_PORT "/dev/null"
#define ALT_LOG_PORT_BASE 0x0
#define ALT_LOG_PORT_DEV null
#define ALT_LOG_PORT_TYPE ""
#define ALT_NUM_EXTERNAL_INTERRUPT_CONTROLLERS 0
#define ALT_NUM_INTERNAL_INTERRUPT_CONTROLLERS 1
#define ALT_NUM_INTERRUPT_CONTROLLERS 1
#define ALT_STDERR "/dev/uart"
#define ALT_STDERR_BASE 0x8001020
#define ALT_STDERR_DEV uart
#define ALT_STDERR_IS_UART
#define ALT_STDERR_PRESENT
#define ALT_STDERR_TYPE "altera_avalon_uart"
#define ALT_STDIN "/dev/uart"
#define ALT_STDIN_BASE 0x8001020
#define ALT_STDIN_DEV uart
#define ALT_STDIN_IS_UART
#define ALT_STDIN_PRESENT
#define ALT_STDIN_TYPE "altera_avalon_uart"
#define ALT_STDOUT "/dev/uart"
#define ALT_STDOUT_BASE 0x8001020
#define ALT_STDOUT_DEV uart
#define ALT_STDOUT_IS_UART
#define ALT_STDOUT_PRESENT
#define ALT_STDOUT_TYPE "altera_avalon_uart"
#define ALT_SYSTEM_NAME "cpu"


/*
 * Time_interval configuration
 *
 */

#define ALT_MODULE_CLASS_Time_interval altera_avalon_pio
#define TIME_INTERVAL_BASE 0x80010a0
#define TIME_INTERVAL_BIT_CLEARING_EDGE_REGISTER 0
#define TIME_INTERVAL_BIT_MODIFYING_OUTPUT_REGISTER 0
#define TIME_INTERVAL_CAPTURE 0
#define TIME_INTERVAL_DATA_WIDTH 32
#define TIME_INTERVAL_DO_TEST_BENCH_WIRING 0
#define TIME_INTERVAL_DRIVEN_SIM_VALUE 0
#define TIME_INTERVAL_EDGE_TYPE "NONE"
#define TIME_INTERVAL_FREQ 100000000
#define TIME_INTERVAL_HAS_IN 1
#define TIME_INTERVAL_HAS_OUT 0
#define TIME_INTERVAL_HAS_TRI 0
#define TIME_INTERVAL_IRQ -1
#define TIME_INTERVAL_IRQ_INTERRUPT_CONTROLLER_ID -1
#define TIME_INTERVAL_IRQ_TYPE "NONE"
#define TIME_INTERVAL_NAME "/dev/Time_interval"
#define TIME_INTERVAL_RESET_VALUE 0
#define TIME_INTERVAL_SPAN 16
#define TIME_INTERVAL_TYPE "altera_avalon_pio"


/*
 * Whole_time_a configuration
 *
 */

#define ALT_MODULE_CLASS_Whole_time_a altera_avalon_pio
#define WHOLE_TIME_A_BASE 0x8001070
#define WHOLE_TIME_A_BIT_CLEARING_EDGE_REGISTER 0
#define WHOLE_TIME_A_BIT_MODIFYING_OUTPUT_REGISTER 0
#define WHOLE_TIME_A_CAPTURE 0
#define WHOLE_TIME_A_DATA_WIDTH 32
#define WHOLE_TIME_A_DO_TEST_BENCH_WIRING 0
#define WHOLE_TIME_A_DRIVEN_SIM_VALUE 0
#define WHOLE_TIME_A_EDGE_TYPE "NONE"
#define WHOLE_TIME_A_FREQ 100000000
#define WHOLE_TIME_A_HAS_IN 1
#define WHOLE_TIME_A_HAS_OUT 0
#define WHOLE_TIME_A_HAS_TRI 0
#define WHOLE_TIME_A_IRQ -1
#define WHOLE_TIME_A_IRQ_INTERRUPT_CONTROLLER_ID -1
#define WHOLE_TIME_A_IRQ_TYPE "NONE"
#define WHOLE_TIME_A_NAME "/dev/Whole_time_a"
#define WHOLE_TIME_A_RESET_VALUE 0
#define WHOLE_TIME_A_SPAN 16
#define WHOLE_TIME_A_TYPE "altera_avalon_pio"


/*
 * Whole_time_b configuration
 *
 */

#define ALT_MODULE_CLASS_Whole_time_b altera_avalon_pio
#define WHOLE_TIME_B_BASE 0x8001060
#define WHOLE_TIME_B_BIT_CLEARING_EDGE_REGISTER 0
#define WHOLE_TIME_B_BIT_MODIFYING_OUTPUT_REGISTER 0
#define WHOLE_TIME_B_CAPTURE 0
#define WHOLE_TIME_B_DATA_WIDTH 32
#define WHOLE_TIME_B_DO_TEST_BENCH_WIRING 0
#define WHOLE_TIME_B_DRIVEN_SIM_VALUE 0
#define WHOLE_TIME_B_EDGE_TYPE "NONE"
#define WHOLE_TIME_B_FREQ 100000000
#define WHOLE_TIME_B_HAS_IN 1
#define WHOLE_TIME_B_HAS_OUT 0
#define WHOLE_TIME_B_HAS_TRI 0
#define WHOLE_TIME_B_IRQ -1
#define WHOLE_TIME_B_IRQ_INTERRUPT_CONTROLLER_ID -1
#define WHOLE_TIME_B_IRQ_TYPE "NONE"
#define WHOLE_TIME_B_NAME "/dev/Whole_time_b"
#define WHOLE_TIME_B_RESET_VALUE 0
#define WHOLE_TIME_B_SPAN 16
#define WHOLE_TIME_B_TYPE "altera_avalon_pio"


/*
 * hal configuration
 *
 */

#define ALT_MAX_FD 32
#define ALT_SYS_CLK TIMER_10MS
#define ALT_TIMESTAMP_CLK none


/*
 * jtag_uart_0 configuration
 *
 */

#define ALT_MODULE_CLASS_jtag_uart_0 altera_avalon_jtag_uart
#define JTAG_UART_0_BASE 0x80010e0
#define JTAG_UART_0_IRQ 1
#define JTAG_UART_0_IRQ_INTERRUPT_CONTROLLER_ID 0
#define JTAG_UART_0_NAME "/dev/jtag_uart_0"
#define JTAG_UART_0_READ_DEPTH 64
#define JTAG_UART_0_READ_THRESHOLD 8
#define JTAG_UART_0_SPAN 8
#define JTAG_UART_0_TYPE "altera_avalon_jtag_uart"
#define JTAG_UART_0_WRITE_DEPTH 64
#define JTAG_UART_0_WRITE_THRESHOLD 8


/*
 * sdram configuration
 *
 */

#define ALT_MODULE_CLASS_sdram altera_avalon_new_sdram_controller
#define SDRAM_BASE 0x4000000
#define SDRAM_CAS_LATENCY 3
#define SDRAM_CONTENTS_INFO
#define SDRAM_INIT_NOP_DELAY 0.0
#define SDRAM_INIT_REFRESH_COMMANDS 2
#define SDRAM_IRQ -1
#define SDRAM_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SDRAM_IS_INITIALIZED 1
#define SDRAM_NAME "/dev/sdram"
#define SDRAM_POWERUP_DELAY 100.0
#define SDRAM_REFRESH_PERIOD 7.8125
#define SDRAM_REGISTER_DATA_IN 1
#define SDRAM_SDRAM_ADDR_WIDTH 0x19
#define SDRAM_SDRAM_BANK_WIDTH 2
#define SDRAM_SDRAM_COL_WIDTH 10
#define SDRAM_SDRAM_DATA_WIDTH 16
#define SDRAM_SDRAM_NUM_BANKS 4
#define SDRAM_SDRAM_NUM_CHIPSELECTS 1
#define SDRAM_SDRAM_ROW_WIDTH 13
#define SDRAM_SHARED_DATA 0
#define SDRAM_SIM_MODEL_BASE 1
#define SDRAM_SPAN 67108864
#define SDRAM_STARVATION_INDICATOR 0
#define SDRAM_TRISTATE_BRIDGE_SLAVE ""
#define SDRAM_TYPE "altera_avalon_new_sdram_controller"
#define SDRAM_T_AC 5.5
#define SDRAM_T_MRD 3
#define SDRAM_T_RCD 20.0
#define SDRAM_T_RFC 70.0
#define SDRAM_T_RP 20.0
#define SDRAM_T_WR 14.0


/*
 * sysid0 configuration
 *
 */

#define ALT_MODULE_CLASS_sysid0 altera_avalon_sysid_qsys
#define SYSID0_BASE 0x80010e8
#define SYSID0_ID 2
#define SYSID0_IRQ -1
#define SYSID0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SYSID0_NAME "/dev/sysid0"
#define SYSID0_SPAN 8
#define SYSID0_TIMESTAMP 1498619909
#define SYSID0_TYPE "altera_avalon_sysid_qsys"


/*
 * timer_10ms configuration
 *
 */

#define ALT_MODULE_CLASS_timer_10ms altera_avalon_timer
#define TIMER_10MS_ALWAYS_RUN 0
#define TIMER_10MS_BASE 0x8001040
#define TIMER_10MS_COUNTER_SIZE 32
#define TIMER_10MS_FIXED_PERIOD 0
#define TIMER_10MS_FREQ 100000000
#define TIMER_10MS_IRQ 0
#define TIMER_10MS_IRQ_INTERRUPT_CONTROLLER_ID 0
#define TIMER_10MS_LOAD_VALUE 999999
#define TIMER_10MS_MULT 0.0010
#define TIMER_10MS_NAME "/dev/timer_10ms"
#define TIMER_10MS_PERIOD 10
#define TIMER_10MS_PERIOD_UNITS "ms"
#define TIMER_10MS_RESET_OUTPUT 0
#define TIMER_10MS_SNAPSHOT 1
#define TIMER_10MS_SPAN 32
#define TIMER_10MS_TICKS_PER_SEC 100.0
#define TIMER_10MS_TIMEOUT_PULSE_OUTPUT 0
#define TIMER_10MS_TYPE "altera_avalon_timer"


/*
 * uart configuration
 *
 */

#define ALT_MODULE_CLASS_uart altera_avalon_uart
#define UART_BASE 0x8001020
#define UART_BAUD 9600
#define UART_DATA_BITS 8
#define UART_FIXED_BAUD 1
#define UART_FREQ 100000000
#define UART_IRQ 2
#define UART_IRQ_INTERRUPT_CONTROLLER_ID 0
#define UART_NAME "/dev/uart"
#define UART_PARITY 'N'
#define UART_SIM_CHAR_STREAM ""
#define UART_SIM_TRUE_BAUD 0
#define UART_SPAN 32
#define UART_STOP_BITS 1
#define UART_SYNC_REG_DEPTH 2
#define UART_TYPE "altera_avalon_uart"
#define UART_USE_CTS_RTS 0
#define UART_USE_EOP_REGISTER 0

#endif /* __SYSTEM_H_ */
