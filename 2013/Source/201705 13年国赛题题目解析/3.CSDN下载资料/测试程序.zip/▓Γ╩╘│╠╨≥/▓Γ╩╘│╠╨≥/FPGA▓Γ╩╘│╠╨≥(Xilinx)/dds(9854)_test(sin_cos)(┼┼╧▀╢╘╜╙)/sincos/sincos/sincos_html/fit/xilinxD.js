var XilinxD="file:///C:/Xilinx/chipviewer/lib/download.htm";
